# Juniper EX Switch Configuration Template

This package contains an Excel template and Python conversion script for generating Juniper EX switch configurations.

## Files Included

1. **juniper_config_template.xlsx** - Excel template with configuration parameters
2. **juniper_excel_to_config.py** - Python script to convert Excel to JunOS set commands
3. **sample_output.txt** - Example output showing generated configuration

## Excel Template Structure

The template contains the following sheets:

### 1. System
- Hostname, domain name, root password
- DNS servers
- Timezone
- Login banner message

### 2. NTP
- NTP server addresses
- Preferred server selection
- Descriptions

### 3. Syslog
- Syslog server addresses
- Facility and severity levels
- Descriptions

### 4. TACACS
- TACACS+ server addresses
- Shared secrets
- Port numbers

### 5. VLANs
- VLAN IDs and names
- Layer 3 interface mappings (IRB)
- Descriptions

### 6. IRB_Interfaces
- IRB interface names (irb.X)
- IP addresses and subnet masks
- VLAN associations

### 7. Interfaces
- Interface names (ge-0/0/X)
- Access/trunk mode configuration
- VLAN assignments
- Speed and duplex settings
- Enable/disable status

### 8. Management
- Out-of-band management interface (me0)
- Management IP address
- Default gateway

### 9. Hardening
- SSH security settings
- Authentication order
- Network security features
- IDS screen thresholds

### 10. SNMP
- Community strings
- SNMPv3 users
- Authentication and privacy settings

## Usage

### Prerequisites

```bash
pip install pandas openpyxl
```

### Converting Excel to JunOS Configuration

```bash
python juniper_excel_to_config.py juniper_config_template.xlsx output_config.txt
```

Or display to stdout:

```bash
python juniper_excel_to_config.py juniper_config_template.xlsx
```

### Applying Configuration to Switch

1. Review the generated configuration file
2. Copy and paste into switch CLI in configuration mode:

```
configure
load set terminal
# Paste configuration here
commit check
commit and-quit
```

Or load from file:

```
configure
load set /path/to/config_file.txt
commit check
commit and-quit
```

## Customization Guide

### Adding New Interfaces

1. Open the **Interfaces** sheet
2. Add a new row with:
   - Interface name (e.g., ge-0/0/10)
   - Description
   - Mode (access or trunk)
   - VLAN assignments
   - Speed (1g, 10g, auto)
   - Duplex (full, auto)
   - Enabled status (YES/NO)

### Adding New VLANs

1. Add VLAN to **VLANs** sheet
2. If Layer 3 routing needed, add corresponding entry to **IRB_Interfaces** sheet

### Security Hardening

Modify the **Hardening** sheet to adjust:
- SSH connection limits
- Authentication methods
- IDS thresholds for flood protection

## Important Notes

### Password Handling
- Root passwords should be pre-encrypted using JunOS `set system root-authentication plain-text-password` command
- TACACS secrets are stored as plain text in Excel (encrypt in production)
- SNMP passwords shown as examples - use strong passwords in production

### Interface Naming
- Physical interfaces: `ge-0/0/X` (GigE), `xe-0/0/X` (10GigE)
- IRB interfaces: `irb.X` where X matches VLAN ID
- Management: `me0` for out-of-band, `vme` for in-band

### VLAN Configuration
- Native VLAN for trunk ports goes in "Native VLAN" column
- Access ports use only "VLANs" column
- Trunk ports list multiple VLANs comma-separated (10,20,30)

### Best Practices

1. **Before deployment:**
   - Review all generated commands
   - Test in lab environment
   - Verify VLAN assignments
   - Check IP addressing scheme

2. **Security:**
   - Change default passwords
   - Use strong TACACS/SNMP secrets
   - Adjust hardening parameters for your environment
   - Enable only required services

3. **Documentation:**
   - Keep Excel template updated
   - Document changes in Description fields
   - Maintain version control

## Example Workflows

### Standard Access Switch
1. Configure VLANs (Data, Voice, Management)
2. Set trunk port to upstream device
3. Configure access ports for endpoints
4. Enable voice VLAN for IP phones
5. Configure management interface

### Distribution Switch
1. Configure VLANs with IRB interfaces
2. Enable IP routing
3. Configure trunk ports to access switches
4. Set up redundancy (VRRP/LACP)
5. Configure uplinks to core

## Troubleshooting

### Common Issues

**Formula errors in Excel:**
- Ensure all required fields are filled
- Check for special characters in descriptions

**Invalid JunOS syntax:**
- Verify VLAN IDs are numeric
- Check interface names match switch model
- Ensure IP addresses have proper CIDR notation

**Configuration won't commit:**
- Run `commit check` to identify errors
- Verify VLAN IDs are unique
- Check for IP address conflicts

## Support

For issues or questions:
- Review JunOS documentation: https://www.juniper.net/documentation/
- Check switch-specific hardware guide
- Validate syntax in JunOS CLI before applying

## Version History

- v1.0 - Initial release with core functionality
  - System, NTP, Syslog, TACACS configuration
  - VLAN and interface management
  - Security hardening options
  - SNMP configuration
